#include <GL/gl.h>
#include <GL/glut.h>
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
float x,y,i;
float counter=0.0;
void init(void)
{
	//gluOrtho2D(0,800,400,0);
	//glOrtho(0,800,500,0,1,-1);
}
void fan(void)
{
    glLineWidth(8);
	glClearColor(0.0,0.0,0.0,0.0);
	glClear(GL_COLOR_BUFFER_BIT);

	glLoadIdentity();

	glBegin(GL_TRIANGLE_FAN);
		glColor3ub(0,0,255);

		for(i=0;i<=2*3.14;i+=0.0001)
		{
			x=0.6*sin(i);
			y=0.6*cos(i);
			glVertex2f(x,y);
		}
	glEnd();

glBegin(GL_TRIANGLE_FAN);
		glColor3ub(138,43,226);

		for(i=0;i<=2*3.14;i+=0.0001)
		{
			x=0.5*sin(i);
			y=0.5*cos(i);
			glVertex2f(x,y);
		}
	glEnd();
    glRotatef(counter,0.0,0.0,-1.0);
	counter+=0.0;
	glBegin(GL_LINES);
		glColor3ub(0,191,255);
		glVertex2f(0,0);
		glVertex2f(0,0.3);
		glVertex2f(0.03,0.5);
glEnd();

    glRotatef(counter,0.0,0.0,-1.0);
	counter+=0.1;
	glBegin(GL_LINES);
		glColor3ub(127,255,212);
		glVertex2f(0.0,0.0);
		glVertex2f(0.4,0.0);
		glVertex2f(0.5,0.03);
glEnd();

glRotatef(counter,0.0,0.0,-1.0);
	counter+=0.98;
	glBegin(GL_LINES);
        glColor3ub(255,255,255);
		glVertex2f(0.0,0.0);
		glVertex2f(-0.4,-0.3);
		glVertex2f(-0.3,-0.4);
	glEnd();
glBegin(GL_TRIANGLE_FAN);
		glColor3ub(0,0,0);

		for(i=0;i<=2*3.14;i+=0.0001)
		{
			x=0.05*sin(i);
			y=0.05*cos(i);
			glVertex2f(x,y);
		}
	glEnd();

	glutSwapBuffers();
}
int main(int argc,char** argv)
{
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_RGB|GLUT_DOUBLE);
	glutInitWindowPosition(-1,-1);
	glutInitWindowSize(640,480);
	glutCreateWindow("Analog Clock");
	init();
	glutDisplayFunc(fan);
	glutIdleFunc(fan);
	glutMainLoop();
	return 0;
}


