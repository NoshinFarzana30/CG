#include <GL/gl.h>
#include <GL/glut.h>
#include<stdio.h>
#include<stdlib.h>
#include<math.h>


float i,x,y;
float g1 = 0;
float g2 = 15;
float g3 = 190;
float g4 = 65;
float g5 = 120;
float g6 = 240;
float g7 = 60;
float g8 = 320;
float moon = 190;


void circle(float r, float g = 0, float f = 0)
{

  glBegin(GL_POINTS);

  for(i=0;i<=2*3.14;i+=0.001)
  {
    x=r*sin(i);
    y=r*cos(i);
    glVertex2f(x,y);
  }
  glEnd();

}

void init(void)
{

}

void draw_circle(float r)
{
  glBegin(GL_TRIANGLE_FAN);

  for(i=0;i<=2*3.14;i+=0.01)
  {
      x=r*sin(i);
      y=r*cos(i);
      glVertex2f(x,y);
  }
  glEnd();
}


void solar(void)
{
  glClearColor(0.0,0.0,0.0,0.0);
  glClear(GL_COLOR_BUFFER_BIT);
  glLoadIdentity();

  glColor3ub(253, 200, 26);
  draw_circle(0.09);

  glColor3ub(255, 255, 255);
  circle(0.15);
  circle(0.26);
  circle(0.37);
  circle(0.48);
  circle(0.59);
  circle(0.7);
  circle(0.81);
  circle(0.92);


glPushMatrix();
glRotatef(g1,0.0,0.0,-1.0);
g1+= 0.5;
glTranslatef(0, 0.15, 0);
glColor3ub(232, 149, 135);
draw_circle(0.02);
glPopMatrix();


glPushMatrix();
glRotatef(g2,0.0,0.0,-1.0);
g2+= 0.3;
glTranslatef(0, 0.26, 0);
glColor3ub(234, 210, 140);
draw_circle(0.035);
glPopMatrix();


glPushMatrix();
glRotatef(g3,0.0,0.0,-1.0);
g3+= 0.036;
glTranslatef(0, 0.37, 0);
glColor3ub(61, 175, 227);
draw_circle(0.05);
glPopMatrix();

glPushMatrix();
glRotatef(moon,0, 0,-1.0);
moon+= 0.036;
glTranslatef(0, 0.435, 0);
glColor3ub(210, 220, 195);
draw_circle(0.01);
glPopMatrix();


glPushMatrix();
glRotatef(g4,0.0,0.0,-1.0);
g4+= 0.07;
glTranslatef(0, 0.48, 0);
glColor3ub(212, 45, 52);
draw_circle(0.03);
glPopMatrix();


glPushMatrix();
glRotatef(g5,0.0,0.0,-1.0);
g5+= 0.06;
glTranslatef(0, 0.59, 0);
glColor3ub(203, 131, 83);
draw_circle(0.07);
glPopMatrix();


glPushMatrix();
glRotatef(g6,0.0,0.0,-1.0);
g6+= 0.0468;
glTranslatef(0, 0.7, 0);
glColor3ub(252, 232, 109);
draw_circle(0.06);
glColor3ub(236, 156, 71);
glBegin(GL_QUADS);
glVertex2f(-0.005, -0.09);
glVertex2f(0.005, -0.09);
glVertex2f(0.005, 0.09);
glVertex2f(-.005, 0.09);
glEnd();
glPopMatrix();

glPushMatrix();
glRotatef(g7,0.0,0.0,-1.0);
g7+= 0.079;
glTranslatef(0, 0.81, 0);
glColor3ub(139, 205, 237);
draw_circle(0.055);
glColor3ub(78, 184, 226);
glBegin(GL_QUADS);
glVertex2f(-0.005, -0.09);
glVertex2f(0.005, -0.09);
glVertex2f(0.005, 0.09);
glVertex2f(-.005, 0.09);
glEnd();
glPopMatrix();

glPushMatrix();
glRotatef(g8,0.0,0.0,-1.0);
g8+= 0.035;
glTranslatef(0, 0.92, 0);
glColor3ub(30, 148, 210);
draw_circle(0.06);
glPopMatrix();



glutSwapBuffers();
}



int main(int argc,char** argv)
{
   glutInit(&argc,argv);
   glutInitDisplayMode(GLUT_RGB|GLUT_DOUBLE);
   glutInitWindowPosition(-1,-1);
   glutInitWindowSize(640,480);
   glutCreateWindow("Solar System");
   init();
   glutDisplayFunc(solar);
   glutIdleFunc(solar);
   glutMainLoop();
   return 0;
}
