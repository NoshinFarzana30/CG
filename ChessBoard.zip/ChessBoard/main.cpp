#include <cstdio>
#include<GL/gl.h>
#include <GL/glut.h>

void myDisplay(void)
{
glClear (GL_COLOR_BUFFER_BIT);
glColor3ub (255, 0, 0);
glPointSize(10.0);

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(80, 0);
glVertex2i(160, 0);
glVertex2i(160, 60);
glVertex2i(80, 60);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(240, 0);
glVertex2i(320, 0);
glVertex2i(320, 60);
glVertex2i(240, 60);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(400, 0);
glVertex2i(480, 0);
glVertex2i(480, 60);
glVertex2i(400, 60);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(560, 0);
glVertex2i(640, 0);
glVertex2i(640, 60);
glVertex2i(560, 60);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(0, 60);
glVertex2i(80, 60);
glVertex2i(80, 120);
glVertex2i(0, 120);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(160, 60);
glVertex2i(240, 60);
glVertex2i(240, 120);
glVertex2i(160, 120);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(320, 60);
glVertex2i(400, 60);
glVertex2i(400, 120);
glVertex2i(320, 120);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(480, 60);
glVertex2i(480, 120);
glVertex2i(560, 120);
glVertex2i(560, 60);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(80, 120);
glVertex2i(160, 120);
glVertex2i(160, 180);
glVertex2i(80, 180);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(240, 120);
glVertex2i(320, 120);
glVertex2i(320, 180);
glVertex2i(240, 180);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(400, 120);
glVertex2i(480, 120);
glVertex2i(480, 180);
glVertex2i(400, 180);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(560, 120);
glVertex2i(640, 120);
glVertex2i(640, 180);
glVertex2i(560, 180);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(0, 180);
glVertex2i(80, 180);
glVertex2i(80, 240);
glVertex2i(0, 240);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(160, 240);
glVertex2i(240, 240);
glVertex2i(240, 180);
glVertex2i(160, 180);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(320, 180);
glVertex2i(400, 180);
glVertex2i(400, 240);
glVertex2i(320, 240);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(480, 180);
glVertex2i(560, 180);
glVertex2i(560, 240);
glVertex2i(480, 240);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(80, 240);
glVertex2i(160, 240);
glVertex2i(160, 300);
glVertex2i(80, 300);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(240, 240);
glVertex2i(320, 240);
glVertex2i(320, 300);
glVertex2i(240, 300);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(400, 300);
glVertex2i(400, 240);
glVertex2i(480, 240);
glVertex2i(480, 300);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(560, 300);
glVertex2i(560, 240);
glVertex2i(660, 240);
glVertex2i(660, 300);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(0, 300);
glVertex2i(80, 300);
glVertex2i(80, 360);
glVertex2i(0, 360);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(160, 300);
glVertex2i(240, 300);
glVertex2i(240, 360);
glVertex2i(160, 360);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(320, 300);
glVertex2i(400, 300);
glVertex2i(400, 360);
glVertex2i(320, 360);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(480, 300);
glVertex2i(560, 300);
glVertex2i(560, 360);
glVertex2i(480, 360);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(80, 360);
glVertex2i(160, 360);
glVertex2i(160, 420);
glVertex2i(80, 420);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(240, 420);
glVertex2i(320, 420);
glVertex2i(320, 360);
glVertex2i(240, 360);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(400, 420);
glVertex2i(480, 420);
glVertex2i(480, 360);
glVertex2i(400, 360);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(560, 420);
glVertex2i(660, 420);
glVertex2i(660, 360);
glVertex2i(560, 360);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(0, 480);
glVertex2i(0, 420);
glVertex2i(80, 420);
glVertex2i(80, 480);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(160, 420);
glVertex2i(240, 420);
glVertex2i(240, 480);
glVertex2i(160, 480);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(320, 420);
glVertex2i(400, 420);
glVertex2i(400, 480);
glVertex2i(320, 480);
glEnd();

glColor3ub (255, 255, 255);
glBegin(GL_QUADS);
glVertex2i(480, 420);
glVertex2i(560, 420);
glVertex2i(560, 480);
glVertex2i(480, 480);
glEnd();
glFlush ();
}

void myInit (void)
{
glClearColor(0.0, 0.0, 0.0, 0.0);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
gluOrtho2D(0.0, 640.0, 0.0, 480.0);
}

int main(int argc, char** argv)
{
glutInit(&argc, argv);
glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
glutInitWindowSize (640, 480);
glutInitWindowPosition (100, 150);
glutCreateWindow ("Chess Board");
glutDisplayFunc(myDisplay);
myInit ();
glutMainLoop();
}
